Add the following to your TE Catalog/Engines/TR1/Moveables.xml file

<moveable id="188" name="Flares (opening box)" id2="187" ten="FLARE_INV_ITEM" />
<moveable id="189" name="Lara's ponytail" hidden="true" ten="HAIR" />
<moveable id="192" name="Lara flare animation" use_body_from="0" hidden="true" ten="FLARE_ANIM" />
<moveable id="193" name="Flare" ten="FLARE_ITEM" />
<moveable id="194" name="Flare burning" hidden="true" />
<moveable id="195" name="Lara T-rex extra skin" hidden="true" use_body_from="0" ten="ANIMATING106" />
<moveable id="196" name="Lara Midas extra skin" hidden="true" use_body_from="0" ten="ANIMATING107" />
<moveable id="197" name="Lara dagger extra skin 1" hidden="true" use_body_from="0" ten="ANIMATING108" />
<moveable id="198" name="Lara dagger extra skin 2" hidden="true" use_body_from="0" ten="ANIMATING109" />
<moveable id="199" name="Lara ponytail swap" hidden="true" ten="ANIMATING110" />


Add this to your TE Catalog/Engines/TR1/SpriteSequences.xml file

<sprite_sequence id="187" name="Flares" />
