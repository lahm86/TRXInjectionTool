Add the following to your TE Catalog/Engines/TR1/Moveables.xml file

<moveable id="188" name="Flares (opening box)" id2="187" ten="FLARE_INV_ITEM" />
<moveable id="189" name="Lara's ponytail" hidden="true" ten="HAIR" />
<moveable id="192" name="Lara flare animation" use_body_from="0" hidden="true" ten="FLARE_ANIM" />
<moveable id="193" name="Flare" ten="FLARE_ITEM" />
<moveable id="194" name="Flare burning" hidden="true" />
<moveable id="195" name="Lara T-rex extra skin" hidden="true" use_body_from="0" ten="ANIMATING106" />
<moveable id="196" name="Lara Midas extra skin" hidden="true" use_body_from="0" ten="ANIMATING107" />
<moveable id="197" name="Lara dagger extra skin 1" hidden="true" use_body_from="0" ten="ANIMATING108" />
<moveable id="198" name="Lara dagger extra skin 2" hidden="true" use_body_from="0" ten="ANIMATING109" />
<moveable id="199" name="Lara ponytail swap" hidden="true" ten="ANIMATING110" />
<moveable id="200" name="Lara hair body swap" hidden="true" ten="ANIMATING111" />
<moveable id="201" name="Lara M16 animation" use_body_from="0" hidden="true" ten="HK_ANIM" />
<moveable id="202" name="Lara grenade-launcher animation" use_body_from="0" hidden="true" ten="GRENADE_ANIM" />
<moveable id="203" name="Lara harpoon-gun animation" use_body_from="0" hidden="true" ten="HARPOON_ANIM" />
<moveable id="204" name="M16" id2="241" ten="HK_ITEM"/>
<moveable id="205" name="Grenade launcher" id2="242" ten="GRENADE_GUN_ITEM"/>
<moveable id="206" name="Harpoon gun" id2="243" ten="HARPOON_ITEM"/>
<moveable id="207" name="M16 ammo" id2="244" ten="HK_AMMO_ITEM"/>
<moveable id="208" name="Grenades" id2="245" ten="GRENADE_GUN_AMMO1_ITEM"/>
<moveable id="209" name="Harpoons" id2="246" ten="HARPOON_AMMO_ITEM"/>
<moveable id="210" name="Gunflare (spiky)" hidden="true" />
<moveable id="211" name="Grenade (single)" hidden="true" ten="GRENADE" />
<moveable id="212" name="Harpoon (flying)" hidden="true" ten="HARPOON" />

Add the following to your TE Catalog/Engines/TR1/SpriteSequences.xml file

<sprite_sequence id="187" name="Flares" />
<sprite_sequence id="241" name="M16" />
<sprite_sequence id="242" name="Grenade launcher" />
<sprite_sequence id="243" name="Harpoon gun" />
<sprite_sequence id="244" name="M16 clips" />    
<sprite_sequence id="245" name="Grenades" />
<sprite_sequence id="246" name="Harpoons" />
