Copy the Moveables.xml file to your local copy of TombEditor to have slot names show up correctly.

E.g. C:\Tomb Editor\Catalogs\Engines\TR3
