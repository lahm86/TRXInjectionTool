Add the following to your TE Catalog/Engines/TR2/Moveables.xml file

<moveable id="270" name="Lara T-rex extra skin" hidden="true" use_body_from="0" ten="ANIMATING106" />
<moveable id="271" name="Lara Midas extra skin" hidden="true" use_body_from="0" ten="ANIMATING107" />
<moveable id="272" name="Lara dagger extra skin 1" hidden="true" use_body_from="0" ten="ANIMATING108" />
<moveable id="273" name="Lara dagger extra skin 2" hidden="true" use_body_from="0" ten="ANIMATING109" />
