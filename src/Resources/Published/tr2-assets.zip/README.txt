Copy the Moveables.xml file to your local copy of TombEditor.

E.g. C:\Tomb Editor\Catalogs\Engines\TR2
